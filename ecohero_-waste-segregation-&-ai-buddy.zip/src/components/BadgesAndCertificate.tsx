import React, { useState } from 'react';
import { Award, Printer, Sparkles, CheckCircle2, Lock } from 'lucide-react';
import { Language, GradeLevel } from '../types';
import { TRANSLATIONS, INITIAL_BADGES } from '../data/translations';
import { playPopSound } from '../utils/audio';

interface BadgesAndCertificateProps {
  language: Language;
  gradeLevel: GradeLevel;
  unlockedBadges: string[];
}

export const BadgesAndCertificate: React.FC<BadgesAndCertificateProps> = ({
  language,
  gradeLevel,
  unlockedBadges,
}) => {
  const t = TRANSLATIONS[language];
  const [studentName, setStudentName] = useState(language === 'mr' ? 'आरव' : 'Aarav');
  const [schoolName, setSchoolName] = useState(language === 'mr' ? 'सरस्वती विद्यामंदिर' : 'Green Valley Public School');

  const todayStr = new Date().toLocaleDateString(language === 'mr' ? 'mr-IN' : 'en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const gradeDisplay = gradeLevel === 'g1-2'
    ? (language === 'mr' ? 'इयत्ता १ ली / २ री' : 'Grade 1 / 2')
    : (language === 'mr' ? 'इयत्ता ३ री / ४ थी' : 'Grade 3 / 4');

  const handlePrint = () => {
    playPopSound();
    window.print();
  };

  return (
    <section id="badges-section" className="py-12 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-widest text-amber-800 bg-amber-100 px-3 py-1 rounded-full border border-amber-300">
            <Award className="w-3.5 h-3.5 text-amber-600" />
            <span>{language === 'mr' ? 'सन्मान व यश' : 'Achievements & Honors'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
            {t.badges.title}
          </h2>
          <p className="text-base text-slate-600 font-medium">
            {t.badges.subtitle}
          </p>
        </div>

        {/* Badges Grid */}
        <div className="mb-12">
          <h3 className="text-lg font-extrabold text-slate-900 mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <span>{t.badges.dailyMissionsTitle}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {INITIAL_BADGES.map((badge) => {
              const isUnlocked = unlockedBadges.includes(badge.id);

              return (
                <div
                  key={badge.id}
                  className={`rounded-3xl p-5 border-2 transition-all flex flex-col justify-between ${
                    isUnlocked
                      ? 'bg-amber-50/60 border-amber-300 shadow-xs'
                      : 'bg-slate-50 border-slate-200 opacity-60'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div
                        className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-xs bg-gradient-to-br ${badge.color} text-white`}
                      >
                        {badge.icon}
                      </div>
                      <span
                        className={`text-2xs font-extrabold px-2 py-0.5 rounded-full ${
                          isUnlocked
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {isUnlocked ? t.badges.unlockedBadge : t.badges.lockedBadge}
                      </span>
                    </div>

                    <h4 className="text-base font-extrabold text-slate-900 font-['Outfit',sans-serif] leading-tight">
                      {language === 'mr' ? badge.titleMr : badge.titleEn}
                    </h4>
                    <p className="text-xs text-slate-600 font-medium mt-1 leading-relaxed">
                      {language === 'mr' ? badge.descriptionMr : badge.descriptionEn}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200 text-2xs font-bold text-slate-500">
                    <span>{language === 'mr' ? badge.requirementMr : badge.requirement}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Certificate Customizer Bar */}
        <div className="bg-amber-50/80 rounded-3xl p-6 border-2 border-amber-300 mb-8 shadow-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-extrabold text-amber-900 block mb-1">
                {t.badges.studentNameLabel}
              </label>
              <input
                type="text"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder={t.badges.studentNamePlaceholder}
                className="w-full px-4 py-2.5 rounded-xl border border-amber-300 bg-white font-bold text-slate-800 focus:outline-hidden focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="text-xs font-extrabold text-amber-900 block mb-1">
                {language === 'mr' ? 'शाळेचे नाव:' : 'School Name:'}
              </label>
              <input
                type="text"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-amber-300 bg-white font-bold text-slate-800 focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Printable Certificate Frame */}
        <div className="relative rounded-3xl border-8 border-double border-amber-500/80 bg-gradient-to-b from-amber-50/40 via-white to-amber-50/40 p-8 sm:p-12 shadow-xl print:m-0 print:border-4">
          
          {/* Top corner ribbons */}
          <div className="absolute top-4 left-4 text-2xl text-emerald-600 select-none">
            🌿
          </div>
          <div className="absolute top-4 right-4 text-2xl text-emerald-600 select-none">
            🌿
          </div>

          <div className="text-center space-y-4">
            
            {/* Certificate Header */}
            <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-amber-100 border border-amber-300 text-amber-900 text-xs font-extrabold tracking-widest uppercase">
              ⭐ {schoolName} ⭐
            </div>

            <h3 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-emerald-900 font-['Outfit',sans-serif]">
              {t.badges.certificateTitle}
            </h3>

            <p className="text-xs sm:text-sm text-slate-500 font-bold uppercase tracking-widest">
              {t.badges.certAwardedTo}
            </p>

            {/* Student Name */}
            <div className="py-2">
              <span className="text-3xl sm:text-5xl font-black text-amber-900 underline decoration-amber-400 decoration-wavy decoration-2 font-['Outfit',sans-serif]">
                {studentName || (language === 'mr' ? 'पर्यावरण हिरो' : 'Eco Hero')}
              </span>
              <span className="block text-xs sm:text-sm font-extrabold text-emerald-800 mt-2">
                {gradeDisplay}
              </span>
            </div>

            {/* Commendation prose */}
            <p className="max-w-xl mx-auto text-xs sm:text-sm text-slate-700 font-medium leading-relaxed">
              {t.badges.certReason}
            </p>

            {/* Bottom signatures and seal row */}
            <div className="pt-8 mt-6 border-t border-amber-200 grid grid-cols-3 items-center gap-4 text-center">
              <div>
                <span className="text-xs sm:text-sm font-black text-slate-800 block">
                  {todayStr}
                </span>
                <span className="text-2xs font-bold text-slate-400 uppercase tracking-wider block">
                  {language === 'mr' ? 'दिनांक' : 'Date'}
                </span>
              </div>

              {/* Gold Seal Emblem */}
              <div className="flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-yellow-500 border-4 border-amber-200 text-amber-950 flex flex-col items-center justify-center shadow-md">
                  <span className="text-xl">🏆</span>
                  <span className="text-3xs font-black uppercase tracking-tighter">ECO HERO</span>
                </div>
              </div>

              <div>
                <span className="text-xs sm:text-sm font-black text-slate-800 block">
                  {language === 'mr' ? 'मुख्याध्यापक व समिती' : 'Principal & Eco Club'}
                </span>
                <span className="text-2xs font-bold text-slate-400 uppercase tracking-wider block">
                  {language === 'mr' ? 'स्वाक्षरी' : 'Authorized Seal'}
                </span>
              </div>
            </div>

          </div>
        </div>

        {/* Print Button */}
        <div className="text-center mt-6">
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-sm shadow-md transition-all active:scale-95"
          >
            <Printer className="w-4 h-4" />
            <span>{t.badges.printBtn}</span>
          </button>
        </div>

      </div>
    </section>
  );
};
