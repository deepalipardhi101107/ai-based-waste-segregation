import React from 'react';
import { Volume2, VolumeX, Globe } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { isSoundEnabled, setSoundEnabled, playPopSound } from '../utils/audio';

interface NavbarProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  setLanguage,
  activeSection,
  setActiveSection,
}) => {
  const [soundOn, setSoundOn] = React.useState(isSoundEnabled());
  const t = TRANSLATIONS[language];

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    setSoundEnabled(next);
    if (next) playPopSound();
  };

  const toggleLanguage = () => {
    playPopSound();
    setLanguage(language === 'en' ? 'mr' : 'en');
  };

  const navItems = [
    { id: 'home', label: t.nav.home },
    { id: 'game', label: t.nav.game },
    { id: 'explorer', label: t.nav.explorer },
    { id: 'chatbot', label: t.nav.chatbot },
    { id: 'badges', label: t.nav.badges },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-amber-200/60 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => {
            playPopSound();
            setActiveSection('home');
          }}
          className="flex items-center gap-2.5 text-left focus-visible:outline-hidden group shrink-0"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-xl shadow-xs group-hover:scale-105 transition-transform">
            🌱
          </div>
          <div>
            <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-emerald-800 whitespace-nowrap block leading-tight font-['Outfit',sans-serif]">
              {language === 'mr' ? 'इको हिरो' : 'EcoHero'}
            </span>
            <span className="text-xs font-semibold text-emerald-600/80 -mt-0.5 block whitespace-nowrap">
              {language === 'mr' ? 'कचरा वर्गीकरण शाळा' : 'Waste Segregation School'}
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-bold text-slate-600">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                playPopSound();
                setActiveSection(item.id);
              }}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 border-b-2 text-base ${
                activeSection === item.id
                  ? 'text-emerald-700 border-emerald-600 font-extrabold'
                  : 'text-slate-600 hover:text-emerald-700 border-transparent'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Controls - Language & Audio */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            aria-label={soundOn ? 'Mute Sound' : 'Enable Sound'}
            title={soundOn ? 'Mute Sound' : 'Enable Sound'}
            className="w-9 h-9 rounded-xl flex items-center justify-center border border-amber-200 bg-amber-50/80 text-amber-800 hover:bg-amber-100 transition-colors"
          >
            {soundOn ? <Volume2 className="w-4 h-4 text-emerald-700" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>

          {/* Bilingual Language Switcher */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border-2 border-emerald-500 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 transition-all font-bold text-sm shadow-xs"
            title="Switch Language / भाषा बदला"
          >
            <Globe className="w-4 h-4 text-emerald-700" />
            <span className="whitespace-nowrap">
              {language === 'en' ? 'मराठी' : 'English'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile quick navigation row */}
      <div className="md:hidden flex items-center justify-around py-2 px-2 bg-amber-50/70 border-t border-amber-100 overflow-x-auto text-xs font-bold text-slate-600">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              playPopSound();
              setActiveSection(item.id);
            }}
            className={`px-2 py-1 rounded-lg whitespace-nowrap transition-colors ${
              activeSection === item.id
                ? 'bg-emerald-600 text-white font-extrabold shadow-xs'
                : 'text-slate-700 hover:bg-emerald-100/50'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>
  );
};
