import React, { useState } from 'react';
import { Search, Volume2, Sparkles, MessageSquare, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Language, WasteItem } from '../types';
import { WASTE_ITEMS, BINS_INFO } from '../data/wasteData';
import { TRANSLATIONS } from '../data/translations';
import { speakText } from '../utils/speech';
import { playPopSound } from '../utils/audio';

interface WasteExplorerProps {
  language: Language;
  onAskAiAboutItem: (itemName: string) => void;
}

export const WasteExplorer: React.FC<WasteExplorerProps> = ({
  language,
  onAskAiAboutItem,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'food' | 'paper' | 'plastic' | 'hazard'>('all');
  const [activeItem, setActiveItem] = useState<WasteItem>(WASTE_ITEMS[0]);
  const t = TRANSLATIONS[language];

  const handleSpeak = (item: WasteItem) => {
    playPopSound();
    const textToSpeak = language === 'mr'
      ? `${item.nameMr}. हा कचरा ${BINS_INFO[item.bin].nameMr}ात जातो. ${item.tipMr}. ${item.funFactMr}`
      : `${item.nameEn}. This item goes into the ${BINS_INFO[item.bin].nameEn}. ${item.tipEn}. ${item.funFactEn}`;
    speakText(textToSpeak, language);
  };

  // Filter items based on query and category
  const filteredItems = WASTE_ITEMS.filter((item) => {
    const matchesCategory =
      selectedCategory === 'all' ||
      (selectedCategory === 'food' && (item.category === 'food' || item.category === 'nature')) ||
      (selectedCategory === 'paper' && item.category === 'paper') ||
      (selectedCategory === 'plastic' && (item.category === 'plastic' || item.category === 'metal' || item.category === 'glass')) ||
      (selectedCategory === 'hazard' && item.category === 'hazard');

    const q = searchQuery.toLowerCase().trim();
    const matchesQuery =
      !q ||
      item.nameEn.toLowerCase().includes(q) ||
      item.nameMr.toLowerCase().includes(q) ||
      item.tipEn.toLowerCase().includes(q) ||
      item.tipMr.toLowerCase().includes(q);

    return matchesCategory && matchesQuery;
  });

  return (
    <section id="explorer-section" className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-8 space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>{language === 'mr' ? 'बाल ज्ञानकोश' : 'Visual Encyclopedia'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
            {t.explorer.title}
          </h2>
          <p className="text-base text-slate-600 font-medium">
            {t.explorer.subtitle}
          </p>
        </div>

        {/* Search & Category Filter Controls */}
        <div className="mb-8 space-y-4 max-w-4xl mx-auto">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.explorer.searchPlaceholder}
              className="w-full pl-12 pr-4 py-3.5 rounded-2xl border-2 border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-500 focus:outline-hidden text-sm sm:text-base font-bold text-slate-800 transition-all shadow-2xs"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {[
              { id: 'all', label: t.explorer.allCategory, icon: '🌟' },
              { id: 'food', label: t.explorer.foodCategory, icon: '🍎' },
              { id: 'paper', label: t.explorer.paperCategory, icon: '📄' },
              { id: 'plastic', label: t.explorer.plasticCategory, icon: '🧴' },
              { id: 'hazard', label: t.explorer.hazardCategory, icon: '🔋' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  playPopSound();
                  setSelectedCategory(cat.id as any);
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-extrabold transition-all flex items-center gap-1.5 ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-600 text-white shadow-xs scale-103'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <span>{cat.icon}</span>
                <span className="whitespace-nowrap">{cat.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Master-Detail Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Grid: Clickable Waste Items */}
          <div className="lg:col-span-7">
            {filteredItems.length === 0 ? (
              <div className="p-8 text-center bg-amber-50/60 rounded-3xl border border-amber-200 text-slate-600 font-medium text-sm">
                {t.explorer.emptySearch}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {filteredItems.map((item) => {
                  const isSelected = activeItem.id === item.id;
                  const binMeta = BINS_INFO[item.bin];

                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        playPopSound();
                        setActiveItem(item);
                      }}
                      className={`relative rounded-2xl p-3.5 text-left border-2 transition-all flex flex-col justify-between ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-50/80 shadow-md ring-2 ring-emerald-300'
                          : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-1 mb-2">
                        <span className="text-3xl">{item.icon}</span>
                        <span
                          className={`text-2xs font-extrabold px-1.5 py-0.5 rounded-md text-white ${
                            item.bin === 'green'
                              ? 'bg-emerald-600'
                              : item.bin === 'blue'
                              ? 'bg-blue-600'
                              : 'bg-rose-600'
                          }`}
                        >
                          {item.bin === 'green' ? '🟢 Wet' : item.bin === 'blue' ? '🔵 Dry' : '🔴 Hazard'}
                        </span>
                      </div>
                      <div>
                        <span className="text-xs sm:text-sm font-extrabold text-slate-900 block leading-tight">
                          {language === 'mr' ? item.nameMr : item.nameEn}
                        </span>
                        <span className="text-2xs font-semibold text-slate-500 block mt-0.5">
                          {language === 'mr' ? binMeta.nameMr : binMeta.nameEn}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Inspector: Active Item Spotlight */}
          <div className="lg:col-span-5 sticky top-24">
            <div className="rounded-3xl border-2 border-emerald-300 bg-gradient-to-b from-white to-emerald-50/40 p-6 shadow-md space-y-5">
              
              {/* Header with Icon, Name, and Speak Button */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-2xl bg-amber-100 flex items-center justify-center text-4xl shadow-2xs">
                    {activeItem.icon}
                  </div>
                  <div>
                    <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
                      {language === 'mr' ? activeItem.nameMr : activeItem.nameEn}
                    </h3>
                    {/* Bin indicator badge */}
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-xs font-bold text-slate-600">
                        {t.explorer.whichBin}
                      </span>
                      <span
                        className={`text-xs font-extrabold px-2 py-0.5 rounded-lg text-white ${
                          activeItem.bin === 'green'
                            ? 'bg-emerald-600'
                            : activeItem.bin === 'blue'
                            ? 'bg-blue-600'
                            : 'bg-rose-600'
                        }`}
                      >
                        {language === 'mr' ? BINS_INFO[activeItem.bin].nameMr : BINS_INFO[activeItem.bin].nameEn}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Speak button */}
                <button
                  onClick={() => handleSpeak(activeItem)}
                  title="Listen aloud"
                  className="p-2.5 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 transition-colors"
                >
                  <Volume2 className="w-5 h-5 text-emerald-700" />
                </button>
              </div>

              {/* Eco Tip Callout */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
                <span className="text-xs font-extrabold text-emerald-800 flex items-center gap-1 mb-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  {t.explorer.tip}
                </span>
                <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed">
                  {language === 'mr' ? activeItem.tipMr : activeItem.tipEn}
                </p>
              </div>

              {/* What it becomes */}
              <div className="p-3.5 rounded-2xl bg-emerald-100/60 border border-emerald-200">
                <span className="text-xs font-extrabold text-emerald-900 flex items-center gap-1 mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                  {t.explorer.whatHappens}
                </span>
                <p className="text-xs sm:text-sm text-emerald-950 font-semibold leading-relaxed">
                  {language === 'mr' ? activeItem.whatHappensMr : activeItem.whatHappensEn}
                </p>
              </div>

              {/* Did you know? */}
              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200">
                <span className="text-xs font-extrabold text-amber-900 flex items-center gap-1 mb-1">
                  💡 {t.explorer.funFact}
                </span>
                <p className="text-xs sm:text-sm text-amber-950 font-medium leading-relaxed">
                  {language === 'mr' ? activeItem.funFactMr : activeItem.funFactEn}
                </p>
              </div>

              {/* One-click: Ask Eco Buddy AI about this */}
              <button
                onClick={() => {
                  playPopSound();
                  const name = language === 'mr' ? activeItem.nameMr : activeItem.nameEn;
                  onAskAiAboutItem(name);
                }}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm shadow-xs transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{t.explorer.askAiAboutThis}</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
