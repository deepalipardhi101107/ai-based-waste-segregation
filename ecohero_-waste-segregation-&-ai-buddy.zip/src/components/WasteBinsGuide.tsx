import React, { useState } from 'react';
import { Volume2, VolumeX, Sparkles, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Language } from '../types';
import { BINS_INFO } from '../data/wasteData';
import { TRANSLATIONS } from '../data/translations';
import { speakText, stopSpeaking } from '../utils/speech';
import { playPopSound } from '../utils/audio';

interface WasteBinsGuideProps {
  language: Language;
  onExploreItem?: (category: string) => void;
}

export const WasteBinsGuide: React.FC<WasteBinsGuideProps> = ({
  language,
}) => {
  const [activeSpeechBin, setActiveSpeechBin] = useState<string | null>(null);
  const t = TRANSLATIONS[language];

  const handleSpeak = (binKey: 'green' | 'blue' | 'red') => {
    playPopSound();
    if (activeSpeechBin === binKey) {
      stopSpeaking();
      setActiveSpeechBin(null);
      return;
    }

    const bin = BINS_INFO[binKey];
    const textToRead = language === 'mr'
      ? `${bin.nameMr}, ${bin.typeMr}. ${bin.descriptionMr}. नेहमीच्या वस्तू: ${bin.examplesMr.join(', ')}.`
      : `${bin.nameEn}, ${bin.typeEn}. ${bin.descriptionEn}. Common items include: ${bin.examplesEn.join(', ')}.`;

    setActiveSpeechBin(binKey);
    speakText(
      textToRead,
      language,
      () => setActiveSpeechBin(binKey),
      () => setActiveSpeechBin(null)
    );
  };

  return (
    <section className="py-12 bg-white border-y border-amber-200/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>{language === 'mr' ? 'मूलभूत नियम' : 'Core Basics'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
            {t.binsSection.title}
          </h2>
          <p className="text-base text-slate-600 font-medium">
            {t.binsSection.subtitle}
          </p>
        </div>

        {/* Feature Image of the 3 cute cartoon bins in school playground */}
        <div className="mb-10 max-w-4xl mx-auto rounded-3xl overflow-hidden border-2 border-amber-200 shadow-md bg-amber-50">
          <div className="relative aspect-16/9 w-full">
            <img
              src="/src/assets/images/waste_bins_trio_cartoon_1793204094282.jpg"
              alt="Cartoon Three Waste Bins Trio"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
              onError={(e) => {
                const target = e.currentTarget;
                target.style.display = 'none';
              }}
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-900/80 via-slate-900/40 to-transparent p-4 sm:p-6 text-white flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-lg font-extrabold leading-tight">
                  {language === 'mr' ? 'शाळेतील आपले तीन मित्र!' : 'Our Three School Friends!'}
                </p>
                <p className="text-xs sm:text-sm text-amber-200 font-medium">
                  {language === 'mr'
                    ? 'ओला कचरा हिरव्यात, सुका कचरा निळ्यात, आणि बॅटरी लाल डब्यात!'
                    : 'Wet goes to Green, Dry goes to Blue, and Hazard goes to Red!'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold bg-white/20 backdrop-blur-xs px-2.5 py-1 rounded-lg">
                  🟢 Green / हिरवा
                </span>
                <span className="text-xs font-bold bg-white/20 backdrop-blur-xs px-2.5 py-1 rounded-lg">
                  🔵 Blue / निळा
                </span>
                <span className="text-xs font-bold bg-white/20 backdrop-blur-xs px-2.5 py-1 rounded-lg">
                  🔴 Red / लाल
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 3 Bin Detailed Interactive Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          
          {/* 1. GREEN BIN */}
          <div className="relative rounded-3xl border-2 border-emerald-300 bg-emerald-50/50 p-6 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
            <div>
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-500 text-white flex items-center justify-center text-3xl shadow-sm">
                    🌱
                  </div>
                  <div>
                    <h3 className="text-xl font-extrabold text-emerald-950 font-['Outfit',sans-serif]">
                      {language === 'mr' ? BINS_INFO.green.nameMr : BINS_INFO.green.nameEn}
                    </h3>
                    <span className="text-xs font-bold text-emerald-700 block">
                      {language === 'mr' ? BINS_INFO.green.typeMr : BINS_INFO.green.typeEn}
                    </span>
                  </div>
                </div>

                {/* Audio Button */}
                <button
                  onClick={() => handleSpeak('green')}
                  title={activeSpeechBin === 'green' ? t.binsSection.stopAudio : t.binsSection.listenBtn}
                  className={`p-2.5 rounded-xl border transition-all ${
                    activeSpeechBin === 'green'
                      ? 'bg-emerald-600 text-white border-emerald-700 animate-pulse'
                      : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                  }`}
                >
                  {activeSpeechBin === 'green' ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>

              <p className="text-sm text-slate-700 mb-5 leading-relaxed font-medium">
                {language === 'mr' ? BINS_INFO.green.descriptionMr : BINS_INFO.green.descriptionEn}
              </p>

              {/* What it turns into box */}
              <div className="p-3.5 rounded-2xl bg-white border border-emerald-200 mb-4 shadow-2xs">
                <span className="text-xs font-extrabold text-emerald-800 flex items-center gap-1 mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  {t.binsSection.compostTurns}
                </span>
                <p className="text-xs text-slate-600 font-semibold leading-relaxed">
                  {language === 'mr'
                    ? 'सुंदर सेंद्रिय खत (कंपोस्ट) जे बागेतील फुले आणि झाडे टवटवीत ठेवते! 🌸'
                    : 'Rich natural compost (manure) that feeds soil and makes flowers bloom! 🌸'}
                </p>
              </div>

              {/* Common items list */}
              <div>
                <span className="text-xs font-bold text-emerald-900 block mb-2">
                  {t.binsSection.examplesTitle}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(language === 'mr' ? BINS_INFO.green.examplesMr : BINS_INFO.green.examplesEn).map((ex, i) => (
                    <span
                      key={i}
                      className="text-xs bg-emerald-100/90 text-emerald-900 font-bold px-2.5 py-1 rounded-lg border border-emerald-200 flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      {ex}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-emerald-200/60 flex items-center justify-between text-xs font-bold text-emerald-800">
              <span>{language === 'mr' ? 'ओला व जैविक कचरा' : '100% Biodegradable'}</span>
              <span>♻️ Compost</span>
            </div>
          </div>

          {/* 2. BLUE BIN */}
          <div className="relative rounded-3xl border-2 border-blue-300 bg-blue-50/50 p-6 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
            <div>
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-blue-500 text-white flex items-center justify-center text-3xl shadow-sm">
                    ♻️
                  </div>
                  <div>
                    <h3 className="text-xl font-extrabold text-blue-950 font-['Outfit',sans-serif]">
                      {language === 'mr' ? BINS_INFO.blue.nameMr : BINS_INFO.blue.nameEn}
                    </h3>
                    <span className="text-xs font-bold text-blue-700 block">
                      {language === 'mr' ? BINS_INFO.blue.typeMr : BINS_INFO.blue.typeEn}
                    </span>
                  </div>
                </div>

                {/* Audio Button */}
                <button
                  onClick={() => handleSpeak('blue')}
                  title={activeSpeechBin === 'blue' ? t.binsSection.stopAudio : t.binsSection.listenBtn}
                  className={`p-2.5 rounded-xl border transition-all ${
                    activeSpeechBin === 'blue'
                      ? 'bg-blue-600 text-white border-blue-700 animate-pulse'
                      : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-100'
                  }`}
                >
                  {activeSpeechBin === 'blue' ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>

              <p className="text-sm text-slate-700 mb-5 leading-relaxed font-medium">
                {language === 'mr' ? BINS_INFO.blue.descriptionMr : BINS_INFO.blue.descriptionEn}
              </p>

              {/* What it turns into box */}
              <div className="p-3.5 rounded-2xl bg-white border border-blue-200 mb-4 shadow-2xs">
                <span className="text-xs font-extrabold text-blue-800 flex items-center gap-1 mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  {t.binsSection.compostTurns}
                </span>
                <p className="text-xs text-slate-600 font-semibold leading-relaxed">
                  {language === 'mr'
                    ? 'नवीन वहीचे कागद, खेळणी, पाण्याचे पाईप आणि सायकलचे भाग! 🚲'
                    : 'Recycled into new notebooks, cool toys, school desks, and bicycle parts! 🚲'}
                </p>
              </div>

              {/* Common items list */}
              <div>
                <span className="text-xs font-bold text-blue-900 block mb-2">
                  {t.binsSection.examplesTitle}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(language === 'mr' ? BINS_INFO.blue.examplesMr : BINS_INFO.blue.examplesEn).map((ex, i) => (
                    <span
                      key={i}
                      className="text-xs bg-blue-100/90 text-blue-900 font-bold px-2.5 py-1 rounded-lg border border-blue-200 flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3 h-3 text-blue-600" />
                      {ex}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-blue-200/60 flex items-center justify-between text-xs font-bold text-blue-800">
              <span>{language === 'mr' ? 'स्वच्छ व सुका ठेवा' : 'Clean & Dry Only'}</span>
              <span>🔄 Recyclable</span>
            </div>
          </div>

          {/* 3. RED BIN */}
          <div className="relative rounded-3xl border-2 border-rose-300 bg-rose-50/50 p-6 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
            <div>
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-rose-500 text-white flex items-center justify-center text-3xl shadow-sm">
                    ⚠️
                  </div>
                  <div>
                    <h3 className="text-xl font-extrabold text-rose-950 font-['Outfit',sans-serif]">
                      {language === 'mr' ? BINS_INFO.red.nameMr : BINS_INFO.red.nameEn}
                    </h3>
                    <span className="text-xs font-bold text-rose-700 block">
                      {language === 'mr' ? BINS_INFO.red.typeMr : BINS_INFO.red.typeEn}
                    </span>
                  </div>
                </div>

                {/* Audio Button */}
                <button
                  onClick={() => handleSpeak('red')}
                  title={activeSpeechBin === 'red' ? t.binsSection.stopAudio : t.binsSection.listenBtn}
                  className={`p-2.5 rounded-xl border transition-all ${
                    activeSpeechBin === 'red'
                      ? 'bg-rose-600 text-white border-rose-700 animate-pulse'
                      : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-100'
                  }`}
                >
                  {activeSpeechBin === 'red' ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>

              <p className="text-sm text-slate-700 mb-5 leading-relaxed font-medium">
                {language === 'mr' ? BINS_INFO.red.descriptionMr : BINS_INFO.red.descriptionEn}
              </p>

              {/* Special care notice */}
              <div className="p-3.5 rounded-2xl bg-white border border-rose-200 mb-4 shadow-2xs">
                <span className="text-xs font-extrabold text-rose-800 flex items-center gap-1 mb-1">
                  <Sparkles className="w-3.5 h-3.5 text-rose-600" />
                  {language === 'mr' ? 'विशेष बाल सुरक्षा नियम:' : 'Important Safety Rule:'}
                </span>
                <p className="text-xs text-slate-600 font-semibold leading-relaxed">
                  {language === 'mr'
                    ? 'बॅटरी व काच स्वतः हाताळू नका, शिक्षकांना किंवा पालकांना सांगा! 🛡️'
                    : 'Always ask a teacher or parent to help handle batteries and broken glass! 🛡️'}
                </p>
              </div>

              {/* Common items list */}
              <div>
                <span className="text-xs font-bold text-rose-900 block mb-2">
                  {t.binsSection.examplesTitle}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(language === 'mr' ? BINS_INFO.red.examplesMr : BINS_INFO.red.examplesEn).map((ex, i) => (
                    <span
                      key={i}
                      className="text-xs bg-rose-100/90 text-rose-900 font-bold px-2.5 py-1 rounded-lg border border-rose-200 flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3 h-3 text-rose-600" />
                      {ex}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-rose-200/60 flex items-center justify-between text-xs font-bold text-rose-800">
              <span>{language === 'mr' ? 'मोठ्यांची मदत घ्या' : 'Adult Care Required'}</span>
              <span>🛡️ Safe Disposal</span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
