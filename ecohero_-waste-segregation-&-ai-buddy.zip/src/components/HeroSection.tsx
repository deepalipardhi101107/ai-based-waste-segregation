import React from 'react';
import { Sparkles, Gamepad2, MessageSquareText, Award } from 'lucide-react';
import { Language, GradeLevel } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { playPopSound } from '../utils/audio';

interface HeroSectionProps {
  language: Language;
  gradeLevel: GradeLevel;
  setGradeLevel: (grade: GradeLevel) => void;
  onNavigate: (section: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  language,
  gradeLevel,
  setGradeLevel,
  onNavigate,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <section className="relative overflow-hidden pt-6 pb-12 sm:pt-10 sm:pb-16 bg-gradient-to-b from-emerald-50/60 via-amber-50/40 to-transparent">
      {/* Background playful floating shapes */}
      <div className="absolute top-10 left-10 text-emerald-200/50 text-6xl select-none pointer-events-none animate-bounce duration-1000">
        🍃
      </div>
      <div className="absolute bottom-6 right-8 text-amber-200/50 text-5xl select-none pointer-events-none animate-pulse">
        ⭐
      </div>
      <div className="absolute top-1/2 right-12 text-blue-200/40 text-4xl select-none pointer-events-none">
        💧
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Column: Greeting & Action */}
          <div className="lg:col-span-7 space-y-5 text-center lg:text-left">
            
            {/* Grade Badge kicker */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs sm:text-sm font-bold tracking-wide border border-emerald-300 shadow-2xs">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>{t.hero.tag}</span>
              <span className="text-emerald-500">|</span>
              <span className="text-emerald-700">मराठी & English</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight font-['Outfit',sans-serif] text-balance">
              {t.hero.title}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-700 font-medium max-w-2xl leading-relaxed">
              {t.hero.description}
            </p>

            {/* Grade Switcher Controls */}
            <div className="pt-2 pb-1">
              <div className="inline-flex flex-col sm:flex-row items-center gap-2 sm:gap-3 bg-white/90 p-2 rounded-2xl border border-amber-200 shadow-xs">
                <span className="text-xs font-bold text-slate-600 px-2">
                  {t.hero.gradeFilterLabel}
                </span>
                <div className="flex items-center gap-1.5 w-full sm:w-auto">
                  <button
                    onClick={() => {
                      playPopSound();
                      setGradeLevel('g1-2');
                    }}
                    className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                      gradeLevel === 'g1-2'
                        ? 'bg-emerald-600 text-white shadow-xs scale-102'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    🌱 {t.hero.grade12}
                  </button>
                  <button
                    onClick={() => {
                      playPopSound();
                      setGradeLevel('g3-4');
                    }}
                    className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                      gradeLevel === 'g3-4'
                        ? 'bg-emerald-600 text-white shadow-xs scale-102'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    🔍 {t.hero.grade34}
                  </button>
                </div>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
              <button
                onClick={() => {
                  playPopSound();
                  onNavigate('game');
                }}
                className="flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-extrabold text-base hover:from-emerald-700 hover:to-teal-700 shadow-md hover:shadow-lg transition-all hover:scale-102 active:scale-98"
              >
                <Gamepad2 className="w-5 h-5" />
                <span>{t.hero.playBtn}</span>
              </button>

              <button
                onClick={() => {
                  playPopSound();
                  onNavigate('chatbot');
                }}
                className="flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-amber-400 text-amber-950 font-extrabold text-base hover:bg-amber-500 shadow-md hover:shadow-lg transition-all hover:scale-102 active:scale-98"
              >
                <MessageSquareText className="w-5 h-5 text-amber-900" />
                <span>{t.hero.askAiBtn}</span>
              </button>

              <button
                onClick={() => {
                  playPopSound();
                  onNavigate('badges');
                }}
                className="flex items-center gap-2 px-4 py-3.5 rounded-2xl border-2 border-slate-300 bg-white text-slate-700 font-bold text-sm hover:border-emerald-500 hover:text-emerald-700 transition-all shadow-2xs"
              >
                <Award className="w-4 h-4 text-amber-600" />
                <span>{language === 'mr' ? 'माझे प्रमाणपत्र' : 'My Certificate'}</span>
              </button>
            </div>

          </div>

          {/* Right Column: Friendly Mascot Card */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative group">
              {/* Outer decorative halo */}
              <div className="absolute -inset-2 bg-gradient-to-r from-emerald-300 to-amber-300 rounded-3xl blur-md opacity-40 group-hover:opacity-60 transition duration-500" />
              
              <div className="relative bg-white rounded-3xl p-4 sm:p-5 border-2 border-emerald-200/80 shadow-xl max-w-sm sm:max-w-md">
                
                {/* Generated Friendly Earth Mascot Image */}
                <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-emerald-50 border border-emerald-100 flex items-center justify-center">
                  <img
                    src="/src/assets/images/eco_mascot_friendly_earth_1793204080520.jpg"
                    alt="Friendly Eco Earth Mascot"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain hover:scale-105 transition-transform duration-300"
                    onError={(e) => {
                      // Fallback container in case image load is interrupted
                      const target = e.currentTarget;
                      target.style.display = 'none';
                    }}
                  />
                  {/* Subtle caption */}
                  <div className="absolute bottom-2 left-2 right-2 bg-white/90 backdrop-blur-xs px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-800">
                      {language === 'mr' ? 'इको मित्र: "पृथ्वीचे रक्षण करा!"' : 'Eco Buddy: "Save Our Earth!"'}
                    </span>
                    <span className="text-xs">⭐⭐⭐</span>
                  </div>
                </div>

                {/* 3 Quick features strip */}
                <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                  <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-100">
                    <span className="text-lg block">🟢</span>
                    <span className="text-xs font-extrabold text-emerald-800 block">
                      {language === 'mr' ? 'ओला कचरा' : 'Wet Waste'}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-blue-50 border border-blue-100">
                    <span className="text-lg block">🔵</span>
                    <span className="text-xs font-extrabold text-blue-800 block">
                      {language === 'mr' ? 'सुका कचरा' : 'Dry Waste'}
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-rose-50 border border-rose-100">
                    <span className="text-lg block">🔴</span>
                    <span className="text-xs font-extrabold text-rose-800 block">
                      {language === 'mr' ? 'घातक कचरा' : 'Hazard'}
                    </span>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
