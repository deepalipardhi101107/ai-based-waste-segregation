import React, { useState, useEffect, useRef } from 'react';
import { Send, Volume2, VolumeX, Sparkles, Bot, User, HelpCircle } from 'lucide-react';
import { Language, ChatMessage } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { speakText, stopSpeaking } from '../utils/speech';
import { playPopSound, playCorrectSound } from '../utils/audio';

interface AiChatbotProps {
  language: Language;
  initialQuestion?: string;
  onClearInitialQuestion?: () => void;
  onUnlockBadge?: (badgeId: string) => void;
}

export const AiChatbot: React.FC<AiChatbotProps> = ({
  language,
  initialQuestion,
  onClearInitialQuestion,
  onUnlockBadge,
}) => {
  const t = TRANSLATIONS[language];
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize welcome message
  useEffect(() => {
    const welcome: ChatMessage = {
      id: 'welcome',
      sender: 'bot',
      text: t.chatbot.welcomeMessage,
      timestamp: new Date(),
    };
    setMessages([welcome]);
  }, [language]);

  // Handle incoming initial question from Waste Explorer
  useEffect(() => {
    if (initialQuestion && initialQuestion.trim()) {
      const q = language === 'mr'
        ? `${initialQuestion} कोणत्या डब्यात टाकावे आणि का?`
        : `Where does ${initialQuestion} go and why?`;
      sendMessage(q);
      if (onClearInitialQuestion) onClearInitialQuestion();
    }
  }, [initialQuestion]);

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const sendMessage = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || loading) return;

    playPopSound();
    stopSpeaking();
    setSpeakingMessageId(null);

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: trimmed,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    if (onUnlockBadge) onUnlockBadge('b4');

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          language: language,
          history: messages.slice(-4).map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            content: m.text,
          })),
        }),
      });

      const data = await response.json();
      const botReply = data.reply || (language === 'mr'
        ? 'शाब्बास! कचरा वर्गीकरण केल्याने आपली पृथ्वी खूप आनंदी होते! 🌱'
        : 'Awesome! Sorting waste keeps Mother Earth healthy and green! 🌱');

      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: botReply,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, botMsg]);
      playCorrectSound();
    } catch (err) {
      console.error('Chat error:', err);
      const fallbackMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'bot',
        text: language === 'mr'
          ? 'इको मित्र सदैव तुमच्यासोबत आहे! ओला कचरा हिरव्यात, सुका कचरा निळ्यात आणि जुनी बॅटरी लाल डब्यात टाका! 🌱'
          : 'Eco Buddy is right here! Remember: Wet waste in Green, Dry waste in Blue, and Hazard in Red! 🌱',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleSpeak = (msgId: string, text: string) => {
    playPopSound();
    if (speakingMessageId === msgId) {
      stopSpeaking();
      setSpeakingMessageId(null);
      return;
    }

    setSpeakingMessageId(msgId);
    speakText(
      text,
      language,
      () => setSpeakingMessageId(msgId),
      () => setSpeakingMessageId(null)
    );
  };

  return (
    <section id="chatbot-section" className="py-12 bg-amber-50/40">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Chatbot Header Card */}
        <div className="bg-white rounded-3xl border-2 border-emerald-300 shadow-lg overflow-hidden flex flex-col h-[700px]">
          
          {/* Top Bar inside Chatbot */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-4 sm:p-5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center text-2xl border border-white/30 shadow-2xs">
                  🌱
                </div>
                <span className="absolute -bottom-1 -right-1 text-sm">⭐</span>
              </div>
              <div>
                <h3 className="text-xl font-extrabold font-['Outfit',sans-serif] leading-tight">
                  {t.chatbot.title}
                </h3>
                <span className="text-xs text-emerald-100 font-semibold block">
                  {t.chatbot.badge}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs bg-white/20 backdrop-blur-xs px-2.5 py-1 rounded-xl font-bold">
                {language === 'mr' ? 'मराठी / English' : 'Bilingual AI'}
              </span>
            </div>
          </div>

          {/* Quick Suggested Questions Bar */}
          <div className="bg-emerald-50/80 border-b border-emerald-100 p-3 overflow-x-auto">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-extrabold text-emerald-900 shrink-0 flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5 text-emerald-600" />
                {t.chatbot.suggestedHeader}
              </span>
              {t.chatbot.quickPrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => sendMessage(prompt)}
                  disabled={loading}
                  className="px-3 py-1 rounded-xl bg-white border border-emerald-200 text-emerald-950 font-bold hover:bg-emerald-100 transition-colors shrink-0 shadow-2xs text-xs whitespace-nowrap active:scale-95"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50/50">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              const isSpeaking = speakingMessageId === msg.id;

              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 items-start ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white flex items-center justify-center text-lg shrink-0 shadow-2xs mt-0.5">
                      🌱
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] sm:max-w-[75%] rounded-3xl p-4 text-sm font-medium shadow-xs ${
                      isUser
                        ? 'bg-emerald-600 text-white rounded-br-xs'
                        : 'bg-white text-slate-800 border-2 border-emerald-200/80 rounded-bl-xs'
                    }`}
                  >
                    <p className="whitespace-pre-line leading-relaxed font-semibold">
                      {msg.text}
                    </p>

                    {/* Listen audio button on bot responses */}
                    {!isUser && (
                      <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-2xs font-bold text-slate-400">
                          {language === 'mr' ? 'इको मित्र AI' : 'Eco Buddy AI'}
                        </span>
                        <button
                          onClick={() => handleSpeak(msg.id, msg.text)}
                          className={`flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-lg border transition-colors ${
                            isSpeaking
                              ? 'bg-emerald-600 text-white border-emerald-700 animate-pulse'
                              : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                          }`}
                        >
                          {isSpeaking ? (
                            <>
                              <VolumeX className="w-3.5 h-3.5" />
                              <span>{t.chatbot.stopBtn}</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5" />
                              <span>{t.chatbot.listenBtn}</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>

                  {isUser && (
                    <div className="w-9 h-9 rounded-xl bg-amber-400 text-amber-950 flex items-center justify-center text-sm font-extrabold shrink-0 shadow-2xs mt-0.5">
                      🧒
                    </div>
                  )}
                </div>
              );
            })}

            {/* Loading indicator */}
            {loading && (
              <div className="flex gap-3 items-start justify-start">
                <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white flex items-center justify-center text-lg shrink-0 shadow-2xs animate-spin">
                  🌱
                </div>
                <div className="bg-white rounded-3xl p-4 border-2 border-emerald-200 shadow-xs flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" />
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce delay-150" />
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce delay-300" />
                  <span className="text-xs font-bold text-emerald-800 ml-2">
                    {t.chatbot.aiThinking}
                  </span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Box Form */}
          <div className="p-3 sm:p-4 bg-white border-t border-slate-200">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                sendMessage(inputText);
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={t.chatbot.placeholder}
                disabled={loading}
                className="flex-1 px-4 py-3.5 rounded-2xl border-2 border-slate-200 bg-slate-50 focus:bg-white focus:border-emerald-500 focus:outline-hidden text-sm sm:text-base font-bold text-slate-800 transition-all placeholder:text-slate-400"
              />
              <button
                type="submit"
                disabled={!inputText.trim() || loading}
                className="px-5 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-extrabold text-sm sm:text-base flex items-center gap-1.5 shadow-xs transition-all active:scale-95 shrink-0"
              >
                <span>{t.chatbot.sendBtn}</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
            <p className="text-2xs text-center text-slate-400 font-semibold mt-2">
              {t.chatbot.disclaimer}
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
