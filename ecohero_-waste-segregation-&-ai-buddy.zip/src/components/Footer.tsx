import React from 'react';
import { Heart, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface FooterProps {
  language: Language;
}

export const Footer: React.FC<FooterProps> = ({ language }) => {
  const t = TRANSLATIONS[language];

  return (
    <footer className="bg-emerald-950 text-emerald-100 py-12 border-t border-emerald-900">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center space-y-6">
        
        {/* School Green Pledge Card */}
        <div className="bg-emerald-900/60 rounded-3xl p-6 sm:p-8 border border-emerald-800/80 shadow-md max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-widest text-amber-300 bg-emerald-800/80 px-3 py-1 rounded-full border border-emerald-700">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.footer.pledgeTitle}</span>
          </div>
          <p className="text-base sm:text-lg font-bold text-white italic leading-relaxed">
            {t.footer.pledgeText}
          </p>
        </div>

        {/* 3 Bin Reminders */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-extrabold text-emerald-200">
          <span className="flex items-center gap-1">
            <span>🟢</span>
            <span>{language === 'mr' ? 'ओला कचरा = हिरवा डबा' : 'Wet Waste = Green Bin'}</span>
          </span>
          <span className="text-emerald-700">•</span>
          <span className="flex items-center gap-1">
            <span>🔵</span>
            <span>{language === 'mr' ? 'सुका कचरा = निळा डबा' : 'Dry Waste = Blue Bin'}</span>
          </span>
          <span className="text-emerald-700">•</span>
          <span className="flex items-center gap-1">
            <span>🔴</span>
            <span>{language === 'mr' ? 'घातक कचरा = लाल डबा' : 'Hazard Waste = Red Bin'}</span>
          </span>
        </div>

        <p className="text-xs text-emerald-400 font-medium">
          {t.footer.credits}
        </p>

      </div>
    </footer>
  );
};
