import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, RotateCcw, Volume2, ArrowDown, Check, Star } from 'lucide-react';
import { Language, WasteItem, BinType, GradeLevel } from '../types';
import { WASTE_ITEMS, BINS_INFO } from '../data/wasteData';
import { TRANSLATIONS } from '../data/translations';
import { playCorrectSound, playIncorrectSound, playFanfareSound, playPopSound } from '../utils/audio';
import { speakText } from '../utils/speech';

interface SortingGameProps {
  language: Language;
  gradeLevel: GradeLevel;
  onUnlockBadge?: (badgeId: string) => void;
}

export const SortingGame: React.FC<SortingGameProps> = ({
  language,
  gradeLevel,
  onUnlockBadge,
}) => {
  const t = TRANSLATIONS[language];

  // Game state
  const [currentLevel, setCurrentLevel] = useState<1 | 2 | 3>(gradeLevel === 'g1-2' ? 1 : 2);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [selectedItem, setSelectedItem] = useState<WasteItem | null>(null);
  const [activeItems, setActiveItems] = useState<WasteItem[]>([]);
  const [sortedItems, setSortedItems] = useState<string[]>([]);
  const [feedback, setFeedback] = useState<{ message: string; isCorrect: boolean } | null>(null);
  const [levelCompleted, setLevelCompleted] = useState<boolean>(false);

  // Initialize level items
  useEffect(() => {
    initLevel(currentLevel);
  }, [currentLevel, gradeLevel]);

  const initLevel = (lvl: 1 | 2 | 3) => {
    let pool = WASTE_ITEMS;
    if (lvl === 1) {
      // Level 1: Only green and blue items, beginner difficulty
      pool = WASTE_ITEMS.filter((item) => (item.bin === 'green' || item.bin === 'blue') && item.difficulty <= 2);
    } else if (lvl === 2) {
      // Level 2: Green, blue, and red items
      pool = WASTE_ITEMS.filter((item) => item.difficulty <= 2);
    } else {
      // Level 3: All items including tricky ones
      pool = WASTE_ITEMS;
    }

    // Shuffle and pick 6 items
    const shuffled = [...pool].sort(() => 0.5 - Math.random()).slice(0, 6);
    setActiveItems(shuffled);
    setSortedItems([]);
    setSelectedItem(shuffled[0] || null);
    setLevelCompleted(false);
    setFeedback(null);
  };

  const handleItemSelect = (item: WasteItem) => {
    if (sortedItems.includes(item.id)) return;
    playPopSound();
    setSelectedItem(item);
  };

  const handleSpeakItem = (e: React.MouseEvent, item: WasteItem) => {
    e.stopPropagation();
    playPopSound();
    const name = language === 'mr' ? item.nameMr : item.nameEn;
    speakText(name, language);
  };

  const handleBinDrop = (binType: BinType) => {
    if (!selectedItem || levelCompleted) return;

    if (selectedItem.bin === binType) {
      // Correct!
      playCorrectSound();
      const newStreak = streak + 1;
      const points = 10 + newStreak * 2;
      setScore((prev) => prev + points);
      setStreak(newStreak);

      const updatedSorted = [...sortedItems, selectedItem.id];
      setSortedItems(updatedSorted);

      const msg = language === 'mr'
        ? `शाब्बास! ${selectedItem.nameMr} ${BINS_INFO[binType].nameMr}ात जाते!`
        : `Awesome! ${selectedItem.nameEn} goes into the ${BINS_INFO[binType].nameEn}!`;
      setFeedback({ message: msg, isCorrect: true });

      // Check badge unlocks
      if (binType === 'green' && onUnlockBadge) onUnlockBadge('b1');
      if (binType === 'blue' && onUnlockBadge) onUnlockBadge('b2');
      if (binType === 'red' && onUnlockBadge) onUnlockBadge('b3');

      // Streak celebration
      if (newStreak % 3 === 0) {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.7 },
        });
      }

      // Find next unsorted item
      const remaining = activeItems.filter((it) => !updatedSorted.includes(it.id));
      if (remaining.length > 0) {
        setSelectedItem(remaining[0]);
      } else {
        // Level complete!
        setSelectedItem(null);
        setLevelCompleted(true);
        playFanfareSound();
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
        });
      }
    } else {
      // Incorrect
      playIncorrectSound();
      setStreak(0);
      const hint = language === 'mr'
        ? `अरेरे! ${selectedItem.nameMr} या डब्यात जात नाही. ${selectedItem.tipMr}`
        : `Oops! ${selectedItem.nameEn} doesn't go there. ${selectedItem.tipEn}`;
      setFeedback({ message: hint, isCorrect: false });
    }
  };

  const handleNextLevel = () => {
    playPopSound();
    const nextLvl = currentLevel === 1 ? 2 : currentLevel === 2 ? 3 : 1;
    setCurrentLevel(nextLvl as 1 | 2 | 3);
  };

  const handleRestart = () => {
    playPopSound();
    setScore(0);
    setStreak(0);
    initLevel(currentLevel);
  };

  return (
    <section id="game-section" className="py-12 bg-amber-50/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Game Title & Stats Bar */}
        <div className="bg-white rounded-3xl p-6 border-2 border-amber-200 shadow-md mb-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl">🎮</span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-['Outfit',sans-serif]">
                  {t.game.title}
                </h2>
              </div>
              <p className="text-sm text-slate-600 font-medium mt-1">
                {t.game.subtitle}
              </p>
            </div>

            {/* Score & Streak display */}
            <div className="flex items-center gap-3">
              <div className="px-4 py-2 rounded-2xl bg-amber-100 border border-amber-300 text-amber-950 font-extrabold flex items-center gap-1.5 shadow-2xs">
                <Trophy className="w-5 h-5 text-amber-600" />
                <span className="text-xs uppercase tracking-wider">{t.game.score}:</span>
                <span className="text-lg font-mono tabular-nums text-amber-900">{score}</span>
              </div>

              <div className="px-3.5 py-2 rounded-2xl bg-emerald-100 border border-emerald-300 text-emerald-950 font-extrabold flex items-center gap-1.5 shadow-2xs">
                <Star className="w-5 h-5 text-emerald-600 fill-emerald-500" />
                <span className="text-xs uppercase tracking-wider">{t.game.streak}:</span>
                <span className="text-lg font-mono tabular-nums text-emerald-900">{streak}</span>
              </div>

              <button
                onClick={handleRestart}
                title={t.game.resetGame}
                className="p-2.5 rounded-2xl border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Level Switcher buttons */}
          <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-500 mr-2">
              {t.game.level}:
            </span>
            {[1, 2, 3].map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  playPopSound();
                  setCurrentLevel(lvl as 1 | 2 | 3);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all ${
                  currentLevel === lvl
                    ? 'bg-emerald-600 text-white shadow-xs scale-105'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {lvl === 1 ? t.game.level1 : lvl === 2 ? t.game.level2 : t.game.level3}
              </button>
            ))}
          </div>
        </div>

        {/* 3 Interactive Waste Bins (Drop/Tap Targets) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
          
          {/* GREEN BIN */}
          <button
            onClick={() => handleBinDrop('green')}
            className="group relative rounded-3xl border-3 border-emerald-500 bg-gradient-to-b from-emerald-50 to-emerald-100/90 p-5 text-left transition-all hover:scale-103 hover:shadow-xl active:scale-98 focus-visible:outline-hidden"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-4xl block transform group-hover:scale-110 transition-transform">
                🌱
              </span>
              <span className="text-xs font-extrabold bg-emerald-600 text-white px-2.5 py-1 rounded-full shadow-2xs">
                {language === 'mr' ? 'ओला कचरा' : 'Wet Waste'}
              </span>
            </div>
            <h3 className="text-xl font-extrabold text-emerald-950 font-['Outfit',sans-serif]">
              {language === 'mr' ? BINS_INFO.green.nameMr : BINS_INFO.green.nameEn}
            </h3>
            <p className="text-xs text-emerald-800 font-semibold mt-1">
              {language === 'mr' ? 'फळांची साले, उरलेले अन्न, पाने' : 'Fruit peels, food, fallen leaves'}
            </p>
            <div className="mt-4 pt-3 border-t border-emerald-200/80 flex items-center justify-between text-xs font-bold text-emerald-700">
              <span>{t.game.dropHere}</span>
              <span className="text-base group-hover:translate-x-1 transition-transform">➡️</span>
            </div>
          </button>

          {/* BLUE BIN */}
          <button
            onClick={() => handleBinDrop('blue')}
            className="group relative rounded-3xl border-3 border-blue-500 bg-gradient-to-b from-blue-50 to-blue-100/90 p-5 text-left transition-all hover:scale-103 hover:shadow-xl active:scale-98 focus-visible:outline-hidden"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-4xl block transform group-hover:scale-110 transition-transform">
                ♻️
              </span>
              <span className="text-xs font-extrabold bg-blue-600 text-white px-2.5 py-1 rounded-full shadow-2xs">
                {language === 'mr' ? 'सुका कचरा' : 'Dry Waste'}
              </span>
            </div>
            <h3 className="text-xl font-extrabold text-blue-950 font-['Outfit',sans-serif]">
              {language === 'mr' ? BINS_INFO.blue.nameMr : BINS_INFO.blue.nameEn}
            </h3>
            <p className="text-xs text-blue-800 font-semibold mt-1">
              {language === 'mr' ? 'कागद, प्लास्टिक बाटली, पुठ्ठा, कॅन' : 'Paper, plastic bottle, cardboard'}
            </p>
            <div className="mt-4 pt-3 border-t border-blue-200/80 flex items-center justify-between text-xs font-bold text-blue-700">
              <span>{t.game.dropHere}</span>
              <span className="text-base group-hover:translate-x-1 transition-transform">➡️</span>
            </div>
          </button>

          {/* RED BIN (Only active in Level 2 & 3, or shown with hint in Level 1) */}
          <button
            onClick={() => handleBinDrop('red')}
            disabled={currentLevel === 1}
            className={`group relative rounded-3xl border-3 border-rose-500 bg-gradient-to-b from-rose-50 to-rose-100/90 p-5 text-left transition-all ${
              currentLevel === 1
                ? 'opacity-40 cursor-not-allowed'
                : 'hover:scale-103 hover:shadow-xl active:scale-98'
            } focus-visible:outline-hidden`}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-4xl block transform group-hover:scale-110 transition-transform">
                ⚠️
              </span>
              <span className="text-xs font-extrabold bg-rose-600 text-white px-2.5 py-1 rounded-full shadow-2xs">
                {language === 'mr' ? 'घातक / ई-कचरा' : 'Hazard & E-Waste'}
              </span>
            </div>
            <h3 className="text-xl font-extrabold text-rose-950 font-['Outfit',sans-serif]">
              {language === 'mr' ? BINS_INFO.red.nameMr : BINS_INFO.red.nameEn}
            </h3>
            <p className="text-xs text-rose-800 font-semibold mt-1">
              {language === 'mr' ? 'जुनी बॅटरी, फुटलेली काच, औषधे' : 'Batteries, broken glass, medicines'}
            </p>
            <div className="mt-4 pt-3 border-t border-rose-200/80 flex items-center justify-between text-xs font-bold text-rose-700">
              <span>{currentLevel === 1 ? (language === 'mr' ? 'पुढील पातळीत उपलब्ध' : 'Available in Level 2') : t.game.dropHere}</span>
              <span className="text-base group-hover:translate-x-1 transition-transform">➡️</span>
            </div>
          </button>

        </div>

        {/* Selected Item Callout Bar */}
        {selectedItem && !levelCompleted && (
          <div className="mb-6 bg-gradient-to-r from-amber-200/70 via-emerald-100/70 to-blue-100/70 p-4 rounded-3xl border-2 border-amber-300 flex flex-wrap items-center justify-between gap-4 animate-pulse">
            <div className="flex items-center gap-3">
              <span className="text-4xl">{selectedItem.icon}</span>
              <div>
                <span className="text-xs font-extrabold text-amber-900 uppercase tracking-wider block">
                  {language === 'mr' ? 'हा कचरा निवडा:' : 'Current Selected Trash:'}
                </span>
                <span className="text-xl font-black text-slate-900 font-['Outfit',sans-serif]">
                  {language === 'mr' ? selectedItem.nameMr : selectedItem.nameEn}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={(e) => handleSpeakItem(e, selectedItem)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white text-slate-800 font-bold text-xs border border-amber-300 shadow-2xs hover:bg-amber-50"
              >
                <Volume2 className="w-4 h-4 text-emerald-600" />
                <span>{language === 'mr' ? 'नाव ऐका' : 'Pronounce'}</span>
              </button>
              <span className="text-xs sm:text-sm font-extrabold text-emerald-800 bg-white px-3 py-1.5 rounded-xl border border-emerald-300 flex items-center gap-1">
                <ArrowDown className="w-4 h-4 animate-bounce text-emerald-600" />
                {t.game.tapBinPrompt}
              </span>
            </div>
          </div>
        )}

        {/* Feedback Alert Toast */}
        {feedback && (
          <div
            className={`mb-6 p-4 rounded-2xl border-2 flex items-center gap-3 font-bold text-sm shadow-xs ${
              feedback.isCorrect
                ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                : 'bg-rose-50 border-rose-300 text-rose-900'
            }`}
          >
            <span className="text-2xl">{feedback.isCorrect ? '🎉' : '💡'}</span>
            <span className="flex-1">{feedback.message}</span>
          </div>
        )}

        {/* Items to sort rack */}
        {!levelCompleted ? (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-extrabold text-slate-800">
                {t.game.dragOrTap}
              </h3>
              <span className="text-xs font-bold text-slate-500">
                {sortedItems.length} / {activeItems.length} {language === 'mr' ? 'पूर्ण' : 'Sorted'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              {activeItems.map((item) => {
                const isSorted = sortedItems.includes(item.id);
                const isSelected = selectedItem?.id === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleItemSelect(item)}
                    disabled={isSorted}
                    className={`relative rounded-2xl p-3 text-center border-2 transition-all flex flex-col items-center justify-center min-h-[110px] ${
                      isSorted
                        ? 'bg-slate-100 border-slate-200 opacity-30 cursor-not-allowed scale-95'
                        : isSelected
                        ? 'bg-amber-100 border-amber-500 shadow-md ring-4 ring-amber-300/60 scale-105'
                        : 'bg-white border-slate-200 hover:border-emerald-400 hover:shadow-xs'
                    }`}
                  >
                    {isSorted && (
                      <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs">
                        <Check className="w-3 h-3" />
                      </div>
                    )}
                    <span className="text-3xl sm:text-4xl mb-1 block">{item.icon}</span>
                    <span className="text-xs font-bold text-slate-800 line-clamp-2 leading-tight">
                      {language === 'mr' ? item.nameMr : item.nameEn}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          /* Level Completed Celebration Card */
          <div className="bg-gradient-to-br from-emerald-500 via-teal-600 to-green-600 text-white rounded-3xl p-8 text-center shadow-xl space-y-4">
            <div className="text-6xl animate-bounce">🏆</div>
            <h3 className="text-2xl sm:text-3xl font-extrabold font-['Outfit',sans-serif]">
              {t.game.completedTitle}
            </h3>
            <p className="text-emerald-100 max-w-lg mx-auto font-medium text-base">
              {t.game.completedDesc}
            </p>
            <div className="flex items-center justify-center gap-4 pt-2">
              <button
                onClick={handleNextLevel}
                className="px-6 py-3 rounded-2xl bg-amber-400 text-amber-950 font-extrabold text-base hover:bg-amber-300 shadow-md hover:scale-105 transition-all"
              >
                {t.game.playAgain}
              </button>
              <button
                onClick={handleRestart}
                className="px-5 py-3 rounded-2xl bg-white/20 text-white font-bold text-sm hover:bg-white/30 backdrop-blur-xs transition-colors"
              >
                {t.game.resetGame}
              </button>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
