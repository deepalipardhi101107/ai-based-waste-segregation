export type Language = 'en' | 'mr';

export type GradeLevel = 'g1-2' | 'g3-4';

export type BinType = 'green' | 'blue' | 'red';

export interface WasteItem {
  id: string;
  nameEn: string;
  nameMr: string;
  category: 'food' | 'paper' | 'plastic' | 'metal' | 'glass' | 'hazard' | 'nature';
  bin: BinType;
  icon: string;
  tipEn: string;
  tipMr: string;
  funFactEn: string;
  funFactMr: string;
  whatHappensEn: string;
  whatHappensMr: string;
  difficulty: 1 | 2 | 3;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
  binSuggestion?: BinType;
}

export interface EcoBadge {
  id: string;
  titleEn: string;
  titleMr: string;
  descriptionEn: string;
  descriptionMr: string;
  icon: string;
  color: string;
  requirement: string;
  requirementMr: string;
  unlocked: boolean;
}
