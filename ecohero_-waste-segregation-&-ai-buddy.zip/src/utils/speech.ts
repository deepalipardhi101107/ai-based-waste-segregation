// Speech synthesis utility for bilingual Marathi & English text-to-speech

let isSpeaking = false;
let currentUtterance: SpeechSynthesisUtterance | null = null;

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
  isSpeaking = false;
  currentUtterance = null;
}

export function speakText(
  text: string,
  lang: 'en' | 'mr',
  onStart?: () => void,
  onEnd?: () => void
) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return;
  }

  stopSpeaking();

  // Strip emojis and markdown characters for cleaner speech
  const cleanText = text
    .replace(/[🌱🍏🍎📦🔋🌍✨⭐🔴🔵🟢♻️]/gu, '')
    .replace(/[*_#`~]/g, '')
    .trim();

  if (!cleanText) return;

  const utterance = new SpeechSynthesisUtterance(cleanText);
  currentUtterance = utterance;

  // Set language
  if (lang === 'mr') {
    utterance.lang = 'mr-IN';
  } else {
    utterance.lang = 'en-US';
  }

  // Find preferred voice if available
  const voices = window.speechSynthesis.getVoices();
  if (voices.length > 0) {
    if (lang === 'mr') {
      const mrVoice = voices.find(
        (v) => v.lang.startsWith('mr') || v.name.toLowerCase().includes('marathi')
      );
      if (mrVoice) {
        utterance.voice = mrVoice;
      } else {
        // Fallback to hindi/indian english voice if available for natural cadence
        const hiVoice = voices.find((v) => v.lang.startsWith('hi') || v.lang === 'en-IN');
        if (hiVoice) utterance.voice = hiVoice;
      }
    } else {
      const enVoice = voices.find(
        (v) => (v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Kid') || v.name.includes('Google')))
      ) || voices.find((v) => v.lang.startsWith('en'));
      if (enVoice) utterance.voice = enVoice;
    }
  }

  utterance.rate = lang === 'mr' ? 0.9 : 0.95; // Slightly gentler rate for young school kids
  utterance.pitch = 1.1; // Cheerful friendly tone

  utterance.onstart = () => {
    isSpeaking = true;
    if (onStart) onStart();
  };

  utterance.onend = () => {
    isSpeaking = false;
    currentUtterance = null;
    if (onEnd) onEnd();
  };

  utterance.onerror = (e) => {
    console.warn('Speech error:', e);
    isSpeaking = false;
    currentUtterance = null;
    if (onEnd) onEnd();
  };

  window.speechSynthesis.speak(utterance);
}

export function isSpeechActive(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.speaking;
}
