/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Language, GradeLevel } from './types';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { WasteBinsGuide } from './components/WasteBinsGuide';
import { SortingGame } from './components/SortingGame';
import { WasteExplorer } from './components/WasteExplorer';
import { AiChatbot } from './components/AiChatbot';
import { BadgesAndCertificate } from './components/BadgesAndCertificate';
import { Footer } from './components/Footer';

export default function App() {
  const [language, setLanguage] = useState<Language>('mr');
  const [gradeLevel, setGradeLevel] = useState<GradeLevel>('g1-2');
  const [activeSection, setActiveSection] = useState<string>('home');
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>(['b1', 'b2']);
  const [initialAiQuestion, setInitialAiQuestion] = useState<string>('');

  const handleUnlockBadge = (badgeId: string) => {
    setUnlockedBadges((prev) => (prev.includes(badgeId) ? prev : [...prev, badgeId]));
  };

  const handleNavigate = (section: string) => {
    setActiveSection(section);
    // Smooth scroll to target section if present
    const el = document.getElementById(`${section}-section`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleAskAiAboutItem = (itemName: string) => {
    setInitialAiQuestion(itemName);
    setActiveSection('chatbot');
    const el = document.getElementById('chatbot-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-amber-50/30 text-slate-800">
      {/* Top Bar Navigation */}
      <Navbar
        language={language}
        setLanguage={setLanguage}
        activeSection={activeSection}
        setActiveSection={handleNavigate}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeSection === 'home' ? (
          <>
            <HeroSection
              language={language}
              gradeLevel={gradeLevel}
              setGradeLevel={setGradeLevel}
              onNavigate={handleNavigate}
            />
            <WasteBinsGuide
              language={language}
            />
            <SortingGame
              language={language}
              gradeLevel={gradeLevel}
              onUnlockBadge={handleUnlockBadge}
            />
            <WasteExplorer
              language={language}
              onAskAiAboutItem={handleAskAiAboutItem}
            />
            <AiChatbot
              language={language}
              initialQuestion={initialAiQuestion}
              onClearInitialQuestion={() => setInitialAiQuestion('')}
              onUnlockBadge={handleUnlockBadge}
            />
            <BadgesAndCertificate
              language={language}
              gradeLevel={gradeLevel}
              unlockedBadges={unlockedBadges}
            />
          </>
        ) : activeSection === 'game' ? (
          <div className="py-6">
            <SortingGame
              language={language}
              gradeLevel={gradeLevel}
              onUnlockBadge={handleUnlockBadge}
            />
          </div>
        ) : activeSection === 'explorer' ? (
          <div className="py-6">
            <WasteExplorer
              language={language}
              onAskAiAboutItem={handleAskAiAboutItem}
            />
          </div>
        ) : activeSection === 'chatbot' ? (
          <div className="py-6">
            <AiChatbot
              language={language}
              initialQuestion={initialAiQuestion}
              onClearInitialQuestion={() => setInitialAiQuestion('')}
              onUnlockBadge={handleUnlockBadge}
            />
          </div>
        ) : activeSection === 'badges' ? (
          <div className="py-6">
            <BadgesAndCertificate
              language={language}
              gradeLevel={gradeLevel}
              unlockedBadges={unlockedBadges}
            />
          </div>
        ) : null}
      </main>

      {/* Footer */}
      <Footer language={language} />
    </div>
  );
}
