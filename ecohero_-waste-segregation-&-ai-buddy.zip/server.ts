import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize GoogleGenAI server-side with User-Agent header
const apiKey = process.env.GEMINI_API_KEY || '';
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// System instruction tailored for Grade 1-4 school students in Marathi & English
const SYSTEM_INSTRUCTION = `You are "Eco Buddy" (इको मित्र), a cheerful, warm, and lovable mascot friend who teaches waste segregation and recycling to elementary school students in Grades 1 to 4 (ages 6 to 10).

Core Knowledge:
1. 🟢 Green Bin (ओला कचरा / Wet Waste): Food scraps, fruit peels (banana, orange), vegetable trimmings, apple cores, tea powder, fallen leaves, egg shells. Mention that it decomposes into rich brown compost (कंपोस्ट खत) which feeds beautiful flowers, vegetables, and trees!
2. 🔵 Blue Bin (सुका कचरा / Dry Waste): Clean plastic bottles, paper, old notebooks, pencil shavings, cardboard, metal cans, milk packets (rinsed and dried), juice cartons. Mention that recyclers melt or mash these to make new notebooks, playground benches, and toys!
3. 🔴 Red Bin (घातक कचरा / Hazardous & E-waste): Old batteries, broken glass, tube lights, expired medicines, thermocol/chemicals. Mention that kids should ask an adult or teacher to handle these carefully!

Response Guidelines for Kids:
- Use very simple, friendly words, short sentences, and cheerful kid-friendly emojis (🌱, 🍏, 📦, 🔋, 🌍, ✨).
- If the user asks in Marathi or specifies Marathi language, answer in warm, simple, natural Marathi (सोपी आणि छान मराठी).
- If the user asks in English or specifies English, answer in enthusiastic, clear, simple English.
- Always clearly state which bin color it belongs to with the emoji (🟢 हिरवा डबा / Green Bin, 🔵 निळा डबा / Blue Bin, 🔴 लाल डबा / Red Bin).
- Keep total length concise (around 3 to 5 short lines max) so 1st to 4th graders can read or listen easily.
- Always conclude with a tiny "⭐ Eco Star Tip" (छान पर्यावरण टीप) or an encouraging cheer.
- If asked about non-environmental topics, kindly guide them back to caring for nature, school cleanliness, and waste sorting!`;

// Gemini Chat Endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { message, language = 'en', history = [] } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!ai) {
      // Friendly fallback if key is temporarily unconfigured
      const isMr = language === 'mr';
      return res.json({
        reply: isMr
          ? 'नमस्ते बालमित्रा! 🌱 मी तुमचा इको मित्र आहे. कचरा वर्गीकरणाबद्दल कोणताही प्रश्न विचारा - जसे की "केळ्याचे साल कोणत्या डब्यात टाकावे?"'
          : 'Hello little Eco Hero! 🌱 I am your Eco Buddy. Ask me anything about waste sorting like "Where do banana peels go?" or "How does recycling work?"'
      });
    }

    const langDirective = language === 'mr' 
      ? 'Note: Please reply in Marathi (मराठी). Keep words simple and friendly for Grade 1-4 kids.'
      : 'Note: Please reply in English. Keep words simple, encouraging, and easy to read for Grade 1-4 students.';

    // Construct conversation context
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    // Add recent history if provided
    if (Array.isArray(history)) {
      for (const item of history.slice(-4)) {
        if (item.role === 'user' || item.role === 'model') {
          contents.push({
            role: item.role,
            parts: [{ text: item.content || item.text || '' }]
          });
        }
      }
    }

    contents.push({
      role: 'user',
      parts: [{ text: `${langDirective}\n\nStudent question: ${message}` }]
    });

    let replyText = '';
    const modelsToTry = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
    let lastError: any = null;

    for (const model of modelsToTry) {
      try {
        const timeoutPromise = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('Model timeout')), 3500)
        );

        const generatePromise = ai.models.generateContent({
          model: model,
          contents: contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.7,
          },
        });

        const response = await Promise.race([generatePromise, timeoutPromise]);
        if (response.text) {
          replyText = response.text;
          break;
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${model} unavailable:`, err?.message || err);
      }
    }

    // If API encountered temporary quota/503 spike, smart knowledge base provides immediate child response
    if (!replyText) {
      // Smart Educational Kid Fallback when API encounters 503 / high demand spikes
      const msgLower = message.toLowerCase();
      const isMr = language === 'mr' || /[\u0900-\u097F]/.test(message);

      if (msgLower.includes('banana') || msgLower.includes('peel') || msgLower.includes('केळ') || msgLower.includes('साल') || msgLower.includes('apple') || msgLower.includes('सफरचंद') || msgLower.includes('roti') || msgLower.includes('पोळी') || msgLower.includes('food') || msgLower.includes('अन्न')) {
        replyText = isMr
          ? `🟢 **हिरवा डबा (ओला कचरा)!**\n\n• हे अन्न व फळांचे अवशेष असल्याने हिरव्या डब्यात जाते.\n• यापासून सुंदर व पौष्टिक **सेंद्रिय खत (कंपोस्ट)** बनते!\n• हे खत झाडे आणि फुलांना छान वाढवते.\n\n⭐ **इको टीप:** डब्यात टाकण्यापूर्वी प्लास्टिकचे स्टिकर नक्की काढून टाका! 🌱`
          : `🟢 **Green Bin (Wet Waste)!**\n\n• Fruit peels and leftover food belong in the Green Bin!\n• In just a few weeks, it turns into rich brown **compost soil** that feeds plants and flowers! 🌸\n\n⭐ **Eco Star Tip:** Always remove any plastic stickers before composting! 🌱`;
      } else if (msgLower.includes('bottle') || msgLower.includes('बाटली') || msgLower.includes('plastic') || msgLower.includes('प्लास्टिक') || msgLower.includes('wrapper') || msgLower.includes('रॅपर') || msgLower.includes('paper') || msgLower.includes('कागद') || msgLower.includes('box') || msgLower.includes('खोके') || msgLower.includes('कॅन') || msgLower.includes('can')) {
        replyText = isMr
          ? `🔵 **निळा डबा (सुका कचरा)!**\n\n• प्लास्टिकच्या बाटल्या, कागद आणि रॅपर निळ्या डब्यात जातात.\n• कारखान्यात हे वितळवून किंवा बारीक करून **नवीन खेळणी, वह्या किंवा कपडे** बनवले जातात!\n\n⭐ **इको टीप:** प्लास्टिकची बाटली चपटी (क्रश) करून डब्यात टाका म्हणजे जागा वाचेल! ♻️`
          : `🔵 **Blue Bin (Dry Waste & Recyclables)!**\n\n• Plastic bottles, clean paper, and clean wrappers go in the Blue Bin!\n• Recyclers melt them into **brand new toys, notebooks, and playground equipment**! 🚲\n\n⭐ **Eco Star Tip:** Crush bottles flat so your school bin has plenty of space! ♻️`;
      } else if (msgLower.includes('battery') || msgLower.includes('बॅटरी') || msgLower.includes('glass') || msgLower.includes('काच') || msgLower.includes('bulb') || msgLower.includes('बल्ब') || msgLower.includes('medicine') || msgLower.includes('औषध')) {
        replyText = isMr
          ? `🔴 **लाल डबा (घातक व ई-कचरा)!**\n\n• बॅटरी आणि फुटलेली काच इतर कचऱ्यात मिसळू नये.\n• यातून रसायने निघू शकतात किंवा कोणालाही कापले जाऊ शकते.\n• हे सुरक्षित विल्हेवाटीसाठी विशेष केंद्रात पाठवले जाते.\n\n⭐ **सुरक्षा टीप:** हे स्वतः टाकू नका, नेहमी शिक्षकांना किंवा आई-बाबांना सांगा! 🛡️`
          : `🔴 **Red Bin (Hazardous & E-Waste)!**\n\n• Batteries, old wires, and broken glass go into the Red Bin!\n• They contain chemicals or sharp edges, so experts recycle them in special safe facilities.\n\n⭐ **Safety Rule:** Always ask a teacher or grown-up to help with hazardous items! 🛡️`;
      } else if (msgLower.includes('pizza') || msgLower.includes('पिझ्झा')) {
        replyText = isMr
          ? `🍕 **पिझ्झा बॉक्सचे काय करावे?**\n\n• जर बॉक्सवर तेल आणि चीज लागले असेल, तर तो तेलकट भाग **हिरव्या डब्यात (ओल्या कचऱ्यात)** टाकावा कारण तेल कागद रिसायकल होऊ देत नाही!\n• वरचा स्वच्छ व सुका पुठ्ठा **निळ्या डब्यात (सुक्या कचऱ्यात)** जातो!\n\n⭐ **इको टीप:** नेहमी स्वच्छ कागदच रिसायकल करता येतो! 📦`
          : `🍕 **What about a Pizza Box?**\n\n• If the bottom is greasy with melted cheese, tear it off and put in **Green Bin** (compost) because grease ruins paper recycling machines!\n• The clean top lid goes right into the **Blue Bin** for recycling!\n\n⭐ **Eco Star Tip:** Only clean, dry paper can be reborn into new books! 📦`;
      } else {
        replyText = isMr
          ? `नमस्ते बालमित्रा! 🌱 मी तुमचा **इको मित्र**!\n\nआपल्याकडे ३ मुख्य डबे आहेत:\n1. 🟢 **हिरवा डबा:** ओला कचरा (फळांची साले, उरलेले अन्न)\n2. 🔵 **निळा डबा:** सुका कचरा (कागद, प्लास्टिक, धातूचे कॅन)\n3. 🔴 **लाल डबा:** घातक कचरा (जुनी बॅटरी, औषधे, काच)\n\nतुम्हाला कोणत्या वस्तूबद्दल जाणून घ्यायचे आहे? नक्की विचारा! ✨`
          : `Hello little Eco Hero! 🌱 I am your **Eco Buddy**!\n\nRemember our 3 superhero bins:\n1. 🟢 **Green Bin:** Wet Waste (fruit peels, roti, lunch leftovers)\n2. 🔵 **Blue Bin:** Dry Waste (paper, plastic bottles, boxes)\n3. 🔴 **Red Bin:** Hazard & E-Waste (used batteries, bulbs, medicines)\n\nAsk me about any trash item, like "Where do milk packets go?"! ✨`;
      }
    }

    return res.json({ reply: replyText });
  } catch (error: any) {
    console.error('Error generating chat response:', error?.message || error);
    const isMr = req.body?.language === 'mr';
    const fallback = isMr
      ? 'शाब्बास! कचरा नेहमी योग्य डब्यात टाका: ओला हिरव्यात, सुका निळ्यात, आणि बॅटरी लाल डब्यात! 🌱'
      : 'Great job! Always sort your waste: Wet in Green, Dry in Blue, and Hazard in Red! 🌱';
    return res.json({ reply: fallback });
  }
});

// Waste classification quick helper endpoint
app.post('/api/classify', async (req, res) => {
  try {
    const { item, language = 'en' } = req.body;
    if (!item || typeof item !== 'string') {
      return res.status(400).json({ error: 'Item name is required' });
    }

    if (!ai) {
      return res.json({
        bin: 'green',
        binName: language === 'mr' ? 'हिरवा डबा (ओला कचरा)' : 'Green Bin (Wet Waste)',
        tip: language === 'mr' ? 'हा कचरा कंपोस्ट खतामध्ये बदलतो!' : 'This turns into rich soil compost!'
      });
    }

    const prompt = `Classify this waste item: "${item}".
Target audience: 1st to 4th grade school students.
Language: ${language === 'mr' ? 'Marathi' : 'English'}.
Which bin does it go into? Answer in JSON format with fields:
- "bin": one of "green", "blue", or "red"
- "binName": Friendly bin name (e.g. "Green Bin (Wet Waste)" or "हिरवा डबा (ओला कचरा)")
- "reason": 1 simple sentence explanation for a child
- "funFact": 1 exciting fact (e.g. "Banana peels make earthworms super happy!")`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    let data;
    try {
      data = JSON.parse(response.text?.trim() || '{}');
    } catch {
      data = {
        bin: 'green',
        binName: language === 'mr' ? 'हिरवा डबा (ओला कचरा)' : 'Green Bin (Wet Waste)',
        reason: language === 'mr' ? 'हे मातीत विरघळते!' : 'This breaks down naturally in soil!',
        funFact: language === 'mr' ? 'झाडे आणि फुलांना हे खत खूप आवडते!' : 'Plants love natural compost!'
      };
    }

    return res.json(data);
  } catch (error) {
    console.error('Error in classify:', error);
    return res.status(500).json({ error: 'Failed to classify' });
  }
});

// Setup Vite or static serving
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    // In development, mount Vite as middleware
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve built static files from dist
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
